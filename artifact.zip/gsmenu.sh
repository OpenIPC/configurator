#!/bin/bash
set -o pipefail

# Configuration
REMOTE_IP="${REMOTE_IP:-10.5.0.10}"
AIR_FIRMWARE_TYPE="${AIR_FIRMWARE_TYPE:-wfb}"
SSH_PASS="12345"
CACHE_DIR="/tmp/gsmenu_cache"
CACHE_TTL=10 # seconds
MAJESTIC_YAML="/etc/majestic.yaml"
WFB_YAML="/etc/wfb.yaml"
ALINK_CONF="/etc/alink.conf"
AALINK_CONF="/etc/aalink.conf"
TXPROFILES_CONF="/etc/txprofiles.conf"
PRESET_DIR="/etc/presets"

# SSH command setup
SSH="timeout -k 1 11 sshpass -p $SSH_PASS ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=10 -o ControlMaster=auto -o ControlPath=/run/ssh_control:%h:%p:%r -o ControlPersist=15s -o ServerAliveInterval=3 -o ServerAliveCountMax=2 root@$REMOTE_IP"
SCP="timeout -k 1 11 sshpass -p $SSH_PASS scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=10 -o ControlMaster=auto -o ControlPath=/run/ssh_control:%h:%p:%r -o ControlPersist=15s -o ServerAliveInterval=3 -o ServerAliveCountMax=2"

# Create cache directory if it doesn't exist
mkdir -p "$CACHE_DIR"

# Function to refresh cached files
refresh_cache() {
    local current_time=$(date +%s)
    local last_refresh=$((current_time - CACHE_TTL))
    
    # Check if we need to refresh
    if [[ ! -f "$CACHE_DIR/last_refresh" ]] || [[ $(cat "$CACHE_DIR/last_refresh") -lt $last_refresh ]]; then
        # Copy the YAML configuration files
        $SCP root@$REMOTE_IP:$MAJESTIC_YAML root@$REMOTE_IP:$WFB_YAML root@$REMOTE_IP:$ALINK_CONF root@$REMOTE_IP:$TXPROFILES_CONF root@$REMOTE_IP:$AALINK_CONF $CACHE_DIR 2>/dev/null

        # Update refresh timestamp
        echo "$current_time" > "$CACHE_DIR/last_refresh"
    fi
}

# Function to get value from majestic.yaml using yaml-cli
get_majestic_value() {
    local key="$1"
    yaml-cli -i "$CACHE_DIR/majestic.yaml" -g "$key" 2>/dev/null
}

# Function to get value from wfb.yaml using yaml-cli
get_wfb_value() {
    local key="$1"
    yaml-cli -i "$CACHE_DIR/wfb.yaml" -g "$key" 2>/dev/null
}

# Function to get value from alink.conf
get_alink_value() {
    local key="$1"
    grep $key= "$CACHE_DIR/alink.conf" | cut -d "=" -f 2 2>/dev/null
}

# Function to get value from alink.conf
get_aalink_value() {
    local key="$1"
    grep ^$key= "$CACHE_DIR/aalink.conf" | cut -d "=" -f 2 2>/dev/null
}

# Refresh cache for get
case "$@" in
  "get air"*)
    [ "$3" != "presets" ] && refresh_cache
    ;;
esac

case "$@" in
    "values air presets preset")
        if [ -d $PRESET_DIR ]; then
            for dir in $PRESET_DIR/presets/*; do
                echo $(basename $dir)
            done
        fi
    ;;
    "values air wfbng mcs_index")
        echo -n 0 10
        ;;
    "values air wfbng fec_k")
        echo -n 0 15
        ;;
    "values air wfbng fec_n")
        echo -n 0 15
        ;;
    "values air wfbng mlink")
        echo -n -e "1500\n1600\n1700\n1800\n1900\n2000\n2100\n2200\n2300\n2400\n2500\n2600\n2700\n2800\n2900\n3000\n3100\n3200\n3300\n3400\n3500\n3600\n3700\n3800\n3900\n4000"
        ;;
    "values air camera contrast")
        echo -n 0 100
        ;;
    "values air camera hue")
        echo -n 0 100
        ;;
    "values air camera saturation")
        echo -n 0 100
        ;;
    "values air camera luminace")
        echo -n 0 100
        ;;
    "values air camera gopsize")
        echo -n 0 10
        ;;
    "values air camera rec_split")
        echo -n 0 60
        ;;
    "values air camera rec_maxusage")
        echo -n 0 100
        ;;
    "values air camera exposure")
        echo -n 5 50
        ;;
    "values air camera noiselevel")
        echo -n 0 1
        ;;
    "values air telemetry osd_fps")
        echo -n 0 60
        ;;
    "values air wfbng power")
        echo -n -e "1\n20\n25\n30\n35\n40\n45\n50\n55\n58"
        ;;
    "values air wfbng air_channel")
        iw list | grep MHz | grep -v disabled | grep -v "radar detection" | grep \* | tr -d '[]' | awk '{print $4 " (" $2 " " $3 ")"}' | grep '^[1-9]' | sort -n |  uniq  | sed -z '$ s/\n$//'
        ;;
    "values air wfbng width")
        echo -n -e "20\n40"
        ;;
    "values air alink power_level_0_to_4")
        echo -n -e "0\n1\n2\n3\n4"
        ;;
    "values air alink fallback_ms")
        echo -n  1 2000
        ;;
    "values air alink hold_fallback_mode_s")
        echo -n  1 10
        ;;
    "values air alink min_between_changes_ms")
        echo -n 1 10000
        ;;
    "values air alink hold_modes_down_s")
        echo -n 1 10
        ;;
    "values air alink hysteresis_percent")
        echo -n 0 100
        ;;
    "values air alink hysteresis_percent_down")
        echo -n 0 100
        ;;
    "values air alink exp_smoothing_factor")
        echo -n 0 1.6
        ;;
    "values air alink exp_smoothing_factor_down")
        echo -n 0 1.6
        ;;
    "values air alink check_xtx_period_ms")
        echo -n 1 5000
        ;;
    "values air alink request_keyframe_interval_ms")
        echo -n 1 5000
        ;;
    "values air alink osd_level")
        echo -n -e "0\n1\n2\n3\n4\n5\n6"
        ;;
    "values air alink multiply_font_size_by")
        echo -n 0 1.5
        ;;
    "values air aalink channel")
        echo -n -e "36\n40\n44\n48\n52\n56\n60\n64\n100\n104\n108\n112\n116\n120\n124\n128\n132\n136\n140\n144\n149\n153\n157\n161\n165\n36_40\n44_48\n52_56\n60_64\n100_104\n108_112\n116_120\n124_128\n132_136\n140_144\n149_153\n157_161"
        ;;
    "values air aalink SCALE_TX_POWER")
        echo -n 0.2 1.2
        ;;
    "values air aalink THRESH_SHIFT")
        echo -n -50 50
        ;;
    "values air aalink OSD_SCALE")
        echo -n 0.2 2
        ;;
    "values air aalink THROUGHPUT_PCT")
        echo -n 0 100
        ;;
    "values air aalink HIGH_TEMP")
        echo -n 70 100
        ;;
    "values air aalink MCS_SOURCE")
        echo -n -e "lowest\ndownlink"
        ;;
    "values air camera size")
        echo -n -e "1280x720\n1456x816\n1920x1080\n1440x1080\n1920x1440\n2104x1184\n2208x1248\n2240x1264\n2312x1304\n2436x1828\n2512x1416\n2560x1440\n2560x1920\n2720x1528\n2944x1656\n3200x1800\n3840x2160"
        ;;
    "values air camera video_mode")
        echo -ne "16:9 720p 30\n\n16:9 720p 30 50HzAC\n16:9 1080p 30\n16:9 1080p 30 50HzAC\n16:9 1440p 30\n16:9 1440p 30 50HzAC\n16:9 4k 2160p 30\n16:9 4k 2160p 30 50HzAC\n16:9 540p 60\n16:9 540p 60 50HzAC\n16:9 720p 60\n16:9 720p 60 50HzAC\n16:9 1080p 60\n16:9 1080p 60 50HzAC\n16:9 1440p 60\n16:9 1440p 60 50HzAC\n16:9 1688p 60\n16:9 1688p 60 50HzAC\n16:9 540p 90\n16:9 540p 90 50HzAC\n16:9 720p 90\n16:9 720p 90 50HzAC\n16:9 1080p 90\n16:9 1080p 90 50HzAC\n16:9 540p 120\n16:9 720p 120\n16:9 816p 120\n4:3 720p 30\n4:3 720p 30 50HzAC\n4:3 960p 30\n4:3 960p 30 50HzAC\n4:3 1080p 30\n4:3 1080p 30 50HzAC\n4:3 1440p 30\n4:3 1440p 30 50HzAC\n4:3 2160p 30\n4:3 2160p 30 50HzAC\n4:3 720p 60\n4:3 720p 60 50HzAC\n4:3 960p 60\n4:3 960p 60 50HzAC\n4:3 1080p 60\n4:3 1080p 60 50HzAC\n4:3 1440p 60\n4:3 1440p 60 50HzAC\n4:3 1688p 60\n4:3 1688p 60 50HzAC\n4:3 720p 90\n4:3 720p 90 50HzAC\n4:3 960p 90\n4:3 960p 90 50HzAC\n4:3 1080p 90\n4:3 1080p 90 50HzAC\n4:3 540p 120\n4:3 720p 120\n4:3 816p 120"
        ;;
    "values air camera fps")
        echo -n -e "60\n90\n120"
        ;;
    "values air camera bitrate")
        echo -n -e "1024\n2048\n3072\n4096\n5120\n6144\n7168\n8192\n9216\n10240\n11264\n12288\n13312\n14336\n15360\n16384\n17408\n18432\n19456\n20480\n21504\n22528\n23552\n24576\n25600\n26624\n27648\n28672\n29692\n30720"
        ;;
    "values air camera codec")
        echo -n -e "h264\nh265"
        ;;
    "values air camera rc_mode")
        echo -n -e "vbr\navbr\ncbr"
        ;;
    "values air camera antiflicker")
        echo -n -e "disabled\n50\n60"
        ;;
    "values air camera sensor_file")
        echo -n -e "imx307\nimx335\nimx335_fpv\nimx415_fpv\nimx415_fpv\nimx415_milos10\nimx415_milos15\nimx335_milos12tweak\nimx335_greg15\nimx335_spike5\ngregspike05"
        ;;
    "values air telemetry serial")
        echo -n -e "ttyS0\nttyS1\nttyS2\nttyS3"
        ;;
    "values air telemetry router")
        echo -n -e "mavfwd\nmsposd"
        ;;

    "get air presets info"*)
        if [ "$5" == "" ] ; then
            echo ""
        else
            echo "Name: $(yaml-cli -i $PRESET_DIR/presets/$5/preset-config.yaml -g .name)"
            echo "Author: $(yaml-cli -i $PRESET_DIR/presets/$5/preset-config.yaml -g .author)"
            echo "Description: $(yaml-cli -i $PRESET_DIR/presets/$5/preset-config.yaml -g .description)"
            echo "Category: $(yaml-cli -i $PRESET_DIR/presets/$5/preset-config.yaml -g .category)"
            echo "Sensor: $(yaml-cli -i $PRESET_DIR/presets/$5/preset-config.yaml -g .sensor)"
            echo "Status: $(yaml-cli -i $PRESET_DIR/presets/$5/preset-config.yaml -g .status)"
            echo "Tags: $(yaml-cli -i $PRESET_DIR/presets/$5/preset-config.yaml -g .tags)"
        fi
    ;;
    "get air presets update")
        mkdir -p $PRESET_DIR
        if [ -d "$PRESET_DIR/.git" ]; then
            # If it's already a git repo, force reset and pull
            cd $PRESET_DIR
            git fetch --all
            git reset --hard origin/master
            git pull origin master --force
        else
            # If not a git repo yet, clone fresh
            git clone https://github.com/OpenIPC/fpv-presets.git $PRESET_DIR
        fi
    ;;
    "get air camera mirror")
        [ "$(get_majestic_value '.image.mirror')" = "true" ] && echo 1 || echo 0
        ;;
    "get air camera flip")
        [ "$(get_majestic_value '.image.flip')" = "true" ] && echo 1 || echo 0
        ;;
    "get air camera contrast")
        get_majestic_value '.image.contrast'
        ;;
    "get air camera hue")
        get_majestic_value '.image.hue'
        ;;
    "get air camera saturation")
        get_majestic_value '.image.saturation'
        ;;
    "get air camera luminace")
        get_majestic_value '.image.luminance'
        ;;
    "get air camera size")
        get_majestic_value '.video0.size'
        ;;
    "get air camera video_mode")
        echo get_current_video_mode | nc -w 11 $REMOTE_IP 12355
        ;;
    "get air camera fps")
        get_majestic_value '.video0.fps'
        ;;
    "get air camera bitrate")
        get_majestic_value '.video0.bitrate'
        ;;
    "get air camera codec")
        get_majestic_value '.video0.codec'
        ;;
    "get air camera gopsize")
        get_majestic_value '.video0.gopSize'
        ;;
    "get air camera rc_mode")
        get_majestic_value '.video0.rcMode'
        ;;
    "get air camera rec_enable")
        [ "$(get_majestic_value '.records.enabled')" = "true" ] && echo 1 || echo 0
        ;;
    "get air camera rec_split")
        get_majestic_value '.records.split'
        ;;
    "get air camera rec_maxusage")
        get_majestic_value '.records.maxUsage'
        ;;
    "get air camera exposure")
        get_majestic_value '.isp.exposure'
        ;;
    "get air camera antiflicker")
        get_majestic_value '.isp.antiFlicker'
        ;;
    "get air camera sensor_file")
        basename -s .bin $(basename $(get_majestic_value '.isp.sensorConfig'))
        ;;
    "get air camera fpv_enable")
        get_majestic_value '.fpv.enabled' | grep -q true && echo 1 || echo 0
        ;;
    "get air camera noiselevel")
        get_majestic_value '.fpv.noiseLevel'
        ;;

    "set air presets "*)
        PRESET="$PRESET_DIR/presets/$4/preset-config.yaml"

        # Create a temporary script file
        REMOTE_SCRIPT=$(mktemp)
        echo "#!/bin/sh" > "$REMOTE_SCRIPT"
        echo "# Auto-generated configuration script" >> "$REMOTE_SCRIPT"
        echo "echo 'Applying configuration...'" >> "$REMOTE_SCRIPT"

        # Process config files
        FILES=$(yq e '.files | keys | .[]' "$PRESET")

        for FILE in $FILES; do
            # Generate CLI commands for each key-value pair
            while IFS= read -r LINE; do
                KEY="${LINE%% *}"    # Get everything before first space
                VALUE="${LINE#* }"   # Get everything after first space
                
                # Escape single quotes in values for bash
                VALUE=${VALUE//\'/\'\\\'\'}
                
                echo "echo \"Setting $KEY to $VALUE in $FILE\"" >> "$REMOTE_SCRIPT"
                echo "cli -i '/etc/$FILE' -s '$KEY' '$VALUE'" >> "$REMOTE_SCRIPT"
            done < <(yq e ".files[\"$FILE\"] | to_entries | .[] | \".\" + .key + \" \" + .value" "$PRESET")
        done

        # Add additional file copies
        yq e '.additional_files // [] | .[]' "$PRESET" | while read -r ADDITIONAL_FILE; do
            LOCAL_FILE="$PRESET_DIR/presets/$4/$ADDITIONAL_FILE"
            if [ -f "$LOCAL_FILE" ]; then
                # Transfer the file first
                $SCP "$LOCAL_FILE" "root@$REMOTE_IP:/etc/"
                echo "echo 'Copied additional file: $ADDITIONAL_FILE'"
            else
                echo "echo 'Warning: Additional file not found: $ADDITIONAL_FILE'"
            fi
        done

        # Add service restart commands
        echo "echo 'Restarting services...'" >> "$REMOTE_SCRIPT"
        echo "(wifibroadcast stop; wifibroadcast stop; sleep 1; wifibroadcast start) >/dev/null 2>&1 &" >> "$REMOTE_SCRIPT"
        echo "killall -1 majestic" >> "$REMOTE_SCRIPT"
        echo "echo 'Configuration applied successfully'" >> "$REMOTE_SCRIPT"

        # Transfer and execute the script
        $SCP "$REMOTE_SCRIPT" "root@$REMOTE_IP:/tmp/apply_config.sh"
        $SSH "sh /tmp/apply_config.sh"

        # Cleanup
        rm "$REMOTE_SCRIPT"
    ;;
    "set air camera mirror"*)
        if [ "$5" = "on" ]
        then 
            $SSH 'cli -s .image.mirror true && killall -1 majestic'
        else
            $SSH 'cli -s .image.mirror false && killall -1 majestic'
        fi
        ;;
    "set air camera flip"*)
        if [ "$5" = "on" ]
        then 
            $SSH 'cli -s .image.flip true && killall -1 majestic'
        else
            $SSH 'cli -s .image.flip false && killall -1 majestic'
        fi
        ;;
    "set air camera contrast"*)
        $SSH "cli -s .image.contrast $5 && killall -1 majestic"
        ;;
    "set air camera hue"*)
        $SSH "cli -s .image.hue $5 && killall -1 majestic"
        ;;
    "set air camera saturation"*)
        $SSH "cli -s .image.saturation $5 && killall -1 majestic"
        ;;
    "set air camera luminace"*)
        $SSH "cli -s .image.luminance $5 && killall -1 majestic"
        ;;
    "set air camera size"*)
        $SSH "cli -s .video0.size $5 && killall -1 majestic"
        ;;
    "set air camera video_mode"*)
        echo set_simple_video_mode "$5" | nc -w 11 $REMOTE_IP 12355
        ;;
    "set air camera fps"*)
        $SSH "cli -s .video0.fps $5 && killall -1 majestic"
        ;;
    "set air camera bitrate"*)
        $SSH "cli -s .video0.bitrate $5 && killall -1 majestic"
        ;;
    "set air camera codec"*)
        $SSH "cli -s .video0.codec $5 && killall -1 majestic"
        ;;
    "set air camera gopsize"*)
        $SSH "cli -s .video0.gopSize $5 && killall -1 majestic"
        ;;
    "set air camera rc_mode"*)
        $SSH "cli -s .video0.rcMode $5 && killall -1 majestic"
        ;;
    "set air camera rec_enable"*)
        if [ "$5" = "on" ]
        then 
            $SSH 'cli -s .records.enable true && killall -1 majestic'
        else
            $SSH 'cli -s .records.enable false && killall -1 majestic'
        fi
        ;;
    "set air camera rec_split"*)
        $SSH "cli -s .records.split $5 && killall -1 majestic"
        ;;
    "set air camera rec_maxusage"*)
        $SSH "cli -s .records.maxUsage $5 && killall -1 majestic"
        ;;
    "set air camera exposure"*)
        $SSH "cli -s .isp.exposure $5 && killall -1 majestic"
        ;;
    "set air camera antiflicker"*)
        $SSH "cli -s .isp.antiFlicker $5 && killall -1 majestic"
        ;;
    "set air camera sensor_file"*)
        $SSH "cli -s .isp.sensorConfig /etc/sensors/${5}.bin && killall -1 majestic"
        ;;
    "set air camera fpv_enable"*)
        if [ "$5" = "on" ]
        then     
            $SSH 'cli -s .fpv.enabled true && killall -1 majestic'
        else
            $SSH 'cli -s .fpv.enabled false && killall -1 majestic'
        fi
        ;;
    "set air camera noiselevel"*)
        $SSH "cli -s .fpv.noiseLevel $5 && killall -1 majestic"
        ;;

    "get air telemetry serial")
        if [ $AIR_FIRMWARE_TYPE = "wfb" ]
        then
            $SSH wifibroadcast cli -g .telemetry.serial
        elif [ $AIR_FIRMWARE_TYPE = "apfpv" ]
        then
            tty=$($SSH "fw_printenv -n msposd_tty")
            if [ ! -z $tty ]
            then
                basename "$tty"
            else
                echo ttyS2
            fi
        fi
        ;;
    "get air telemetry router")
        $SSH wifibroadcast cli -g .telemetry.router
        ;;
    "get air telemetry osd_fps")
        $SSH wifibroadcast cli -g .telemetry.osd_fps
        ;;
    "get air telemetry gs_rendering")
        $SSH 'grep "\-z \"\$size\"" /usr/bin/wifibroadcast' | grep -q size && echo 0 || echo 1
        ;;

    "set air telemetry serial"*)
        if [ "$5" = "ttyS0" ]
        then
          $SSH "sed -i 's/^console::respawn:\/sbin\/getty -L console 0 vt100/#console::respawn:\/sbin\/getty -L console 0 vt100/' /etc/inittab ; kill -HUP 1"
        else
          $SSH "sed -i 's/^#console::respawn:\/sbin\/getty -L console 0 vt100/console::respawn:\/sbin\/getty -L console 0 vt100/' /etc/inittab ; kill -HUP 1"
        fi
        if [ $AIR_FIRMWARE_TYPE = "wfb" ]
        then
            $SSH wifibroadcast cli -s .telemetry.serial $5
            $SSH "(wifibroadcast stop ;wifibroadcast stop; sleep 1;  wifibroadcast start) >/dev/null 2>&1 &"
        elif [ $AIR_FIRMWARE_TYPE = "apfpv" ]
        then
            $SSH "fw_setenv msposd_tty /dev/$5; /etc/init.d/S99msposd stop ; /etc/init.d/S99msposd stop ; sleep 1; /etc/init.d/S99msposd start"
        fi
        ;;
    "set air telemetry router"*)
        $SSH wifibroadcast cli -s .telemetry.router $5
        $SSH "(wifibroadcast stop ;wifibroadcast stop; sleep 1;  wifibroadcast start) >/dev/null 2>&1 &"
        ;;
    "set air telemetry osd_fps"*)
        $SSH wifibroadcast cli -s .telemetry.osd_fps $5
        $SSH "(wifibroadcast stop ;wifibroadcast stop; sleep 1;  wifibroadcast start) >/dev/null 2>&1 &"
        ;;
    "set air telemetry gs_rendering"*)
        if [ "$5" = "on" ]
        then
            $SSH 'sed -i "s/-o 127\.0\.0\.1:\"\$port_tx\" -z \"\$size\"/-o 10\.5\.0\.1:\"\$port_tx\"/" /usr/bin/wifibroadcast'
            $SSH "(wifibroadcast stop ;wifibroadcast stop; sleep 1;  wifibroadcast start) >/dev/null 2>&1 &"
        else
            $SSH 'sed -i "s/-o 10\.5\.0\.1:\"\$port_tx\"/-o 127\.0\.0\.1:\"\$port_tx\" -z \"\$size\"/" /usr/bin/wifibroadcast'
            $SSH "(wifibroadcast stop ;wifibroadcast stop; sleep 1;  wifibroadcast start) >/dev/null 2>&1 &"
        fi
        ;;

    "get air wfbng power")
        get_wfb_value '.wireless.txpower'
        ;;
    "get air wfbng air_channel")
        channel=$(get_wfb_value '.wireless.channel' | tr -d '\n')
        iw list | grep "\[$channel\]" | tr -d '[]' | awk '{print $4 " (" $2 " " $3 ")"}' | sort -n | uniq | tr -d '\n'
        ;;
    "get air wfbng width")
        get_wfb_value '.wireless.width'
        ;;
    "get air wfbng mcs_index")
        get_wfb_value '.broadcast.mcs_index'
        ;;
    "get air wfbng stbc")
        get_wfb_value '.broadcast.stbc'
        ;;
    "get air wfbng ldpc")
        get_wfb_value '.broadcast.ldpc'
        ;;
    "get air wfbng fec_k")
        get_wfb_value '.broadcast.fec_k'
        ;;
    "get air wfbng fec_n")
        get_wfb_value '.broadcast.fec_n'
        ;;
    "get air wfbng mlink")
        get_wfb_value '.wireless.mlink'
        ;;
    "get air wfbng adaptivelink")
        $SSH grep ^alink_drone /etc/rc.local | grep -q 'alink_drone' && echo 1 || echo 0
        ;;

    "set air wfbng power"*)
        $SSH wifibroadcast cli -s .wireless.txpower $5
        $SSH "(wifibroadcast stop ;wifibroadcast stop; sleep 1;  wifibroadcast start) >/dev/null 2>&1 &"
        ;;
    "set air wfbng air_channel"*)
        channel=$(echo $5 | awk '{print $1}')
        $SSH wifibroadcast cli -s .wireless.channel $channel
        $SSH "(wifibroadcast stop ;wifibroadcast stop; sleep 1;  wifibroadcast start) >/dev/null 2>&1 &"
        sed -i "s/^wifi_channel =.*/wifi_channel = $channel/" /etc/wifibroadcast.cfg
        systemctl restart wifibroadcast.service
        ;;
    "set air wfbng width"*)
        $SSH wifibroadcast cli -s .wireless.width $5
        $SSH "(wifibroadcast stop ;wifibroadcast stop; sleep 1;  wifibroadcast start) >/dev/null 2>&1 &"
        ;;
    "set air wfbng mcs_index"*)
        $SSH wifibroadcast cli -s .broadcast.mcs_index $5
        $SSH "(wifibroadcast stop ;wifibroadcast stop; sleep 1;  wifibroadcast start) >/dev/null 2>&1 &"
        ;;
    "set air wfbng stbc"*)
        if [ "$5" = "on" ]
        then 
            $SSH wifibroadcast cli -s .broadcast.stbc 1
        else
            $SSH wifibroadcast cli -s .broadcast.stbc 0
        fi
        $SSH "(wifibroadcast stop ;wifibroadcast stop; sleep 1;  wifibroadcast start) >/dev/null 2>&1 &"
        ;;
    "set air wfbng ldpc"*)
        if [ "$5" = "on" ]
        then 
            $SSH wifibroadcast cli -s .broadcast.ldpc 1
        else
            $SSH wifibroadcast cli -s .broadcast.ldpc 0
            
        fi
        $SSH "(wifibroadcast stop ;wifibroadcast stop; sleep 1;  wifibroadcast start) >/dev/null 2>&1 &"
        ;;
    "set air wfbng fec_k"*)
        $SSH wifibroadcast cli -s .broadcast.fec_k $5
        $SSH "(wifibroadcast stop ;wifibroadcast stop; sleep 1;  wifibroadcast start) >/dev/null 2>&1 &"
        ;;
    "set air wfbng fec_n"*)
        $SSH wifibroadcast cli -s .broadcast.fec_n $5
        $SSH "(wifibroadcast stop ;wifibroadcast stop; sleep 1;  wifibroadcast start) >/dev/null 2>&1 &"
        ;;
    "set air wfbng mlink"*)
        $SSH wifibroadcast cli -s .wireless.mlink $5
        $SSH "(wifibroadcast stop ;wifibroadcast stop; sleep 1;  wifibroadcast start) >/dev/null 2>&1 &"
        ;;
    "set air wfbng adaptivelink"*)
        if [ "$5" = "on" ]
        then
            $SSH 'sed -i "/alink_drone &/d" /etc/rc.local && sed -i -e "\$i alink_drone &" /etc/rc.local && cli -s .video0.qpDelta -12 && killall -1 majestic && (nohup alink_drone >/dev/null 2>&1 &)'
        else
            $SSH 'killall -q -9 alink_drone;  sed -i "/alink_drone &/d" /etc/rc.local  ; cli -d .video0.qpDelta && killall -1 majestic'
        fi
        ;;

    "get gs apfpv ssid")
        nmcli  c show apfpv0 | grep "802-11-wireless.ssid" | cut -d : -f2 | awk ' {print $1}'
        ;;
    "get gs apfpv password")
        nmcli -t connection show apfpv0 --show-secrets | grep 802-11-wireless-security.psk: | cut -d : -f2
        ;;
    "get gs apfpv wlx"*)
        grep -q autoconnect=false $(grep -l $4 /etc/NetworkManager/system-connections/apfpv*.nmconnection) && echo 0 || echo 1
        ;;
    "get gs apfpv status wlx"*)
        nmcli -t device status | grep $5 | grep -q :connected: && echo Connected || echo Disconnected
        ;;
    "set gs apfpv ssid"*)
        if [ "$GSMENU_VTX_DETECTED" -eq "1" ]; then
            $SSH 'fw_setenv wlanssid "'$5'"'
            $SSH '(hostapd_cli -i wlan0 set ssid "'$5'"; hostapd_cli -i wlan0 reload)  >/dev/null 2>&1 &'
        fi
        WIFI_IFACES=$(ip -o link show | awk -F': ' '{print $2}' | grep '^wlx' | grep -v "^$EXCLUDE_IFACE$")
        INDEX=0
        for IFACE in $WIFI_IFACES; do
            CONN_NAME="apfpv$INDEX"
            if nmcli connection show "$CONN_NAME" &>/dev/null; then
                nmcli connection modify "$CONN_NAME" ssid "$5"
                if [ $($0 get gs apfpv $IFACE) = 1 ]
                then
                    nmcli -w 0 connection up "$CONN_NAME"
                fi
            fi
            INDEX=$((INDEX + 1))
        done
        ;;
    "set gs apfpv password"*)
        if [ "$GSMENU_VTX_DETECTED" -eq "1" ]; then
            $SSH 'fw_setenv wlanpass "'$5'"'
            $SSH '(hostapd_cli -i wlan0 set wpa_passphrase "'$5'"; hostapd_cli -i wlan0 reload)  >/dev/null 2>&1 &'
        fi
        WIFI_IFACES=$(ip -o link show | awk -F': ' '{print $2}' | grep '^wlx' | grep -v "^$EXCLUDE_IFACE$")
        INDEX=0
        for IFACE in $WIFI_IFACES; do
            CONN_NAME="apfpv$INDEX"
            if nmcli connection show "$CONN_NAME" &>/dev/null; then
                nmcli connection modify "$CONN_NAME" wifi-sec.psk "$5"
                if [ $($0 get gs apfpv $IFACE) = 1 ]
                then
                    nmcli -w 0 connection up "$CONN_NAME"
                fi
            fi
            INDEX=$((INDEX + 1))
        done
        ;;

    "set gs apfpv wlx"*)
        conn=$(basename -s .nmconnection $(grep -l $4 /etc/NetworkManager/system-connections/apfpv*.nmconnection))
        if [ $5 = "on" ]
        then
            nmcli connection modify "$conn" connection.autoconnect yes
            nmcli connection up "$conn"
        else
            nmcli connection modify "$conn" connection.autoconnect no
            nmcli connection down "$conn"
            DRV_PATH=$(readlink -f /sys/class/net/$4/device/driver 2>/dev/null || true)
            DEV_PATH=$(readlink -f /sys/class/net/$4/device 2>/dev/null || true)
            DRV_NAME=$(basename "$DRV_PATH")
            DEV_NAME=$(basename "$DEV_PATH")
            echo -n "$DEV_NAME" | sudo tee /sys/bus/usb/drivers/$DRV_NAME/unbind >/dev/null
            sleep 1
            echo -n "$DEV_NAME" | sudo tee /sys/bus/usb/drivers/$DRV_NAME/bind >/dev/null
            sleep 1
        fi
        ;;
    "set gs apfpv reset")
            CONNECTIONS=$(nmcli -t c show  | grep ^apfpv | cut -d : -f1)
            for CONN_NAME in $CONNECTIONS; do
                if nmcli connection show "$CONN_NAME" &>/dev/null; then
                    nmcli connection down "$CONN_NAME"
                    nmcli connection delete "$CONN_NAME"
                fi
            done
        ;;
    "get air alink"*)
        get_alink_value $4
        ;;

    "get air aalink channel")
        $SSH "fw_printenv -n wlanchan || echo 157"
        ;;

    "get air aalink"*)
        get_aalink_value $4
        ;;

    "set air aalink channel"*)
        echo "set_ap_channel $5" | nc -w 11 $REMOTE_IP 12355
        ;;

    "set air alink"*)
        if [ "$5" = "off" ]
        then
            $SSH 'sed -i "s/'$4'=.*/'$4'=0/" /etc/alink.conf; killall -9 alink_drone ; alink_drone &'
        elif [ "$5" = "on" ]
        then
            $SSH 'sed -i "s/'$4'=.*/'$4'=1/" /etc/alink.conf; killall -9 alink_drone ; alink_drone &'
        elif [ "$4" = "txprofiles" ]
        then
            $SCP $CACHE_DIR/txprofiles.conf root@$REMOTE_IP:$TXPROFILES_CONF
            $SSH 'killall -9 alink_drone ; alink_drone &'
        else
            $SSH 'sed -i "s/'$4'=.*/'$4'='$5'/" /etc/alink.conf; killall -9 alink_drone ; alink_drone &'
        fi
        ;;

    "set air aalink"*)
            $SSH 'sed -i "s/'$4'=.*/'$4'='$5'/" /etc/aalink.conf; kill -SIGHUP $(pidof aalink)'
        ;;

    "values gs wfbng gs_channel")
        iw list | grep MHz | grep -v disabled | grep -v "radar detection" | grep \* | tr -d '[]' | awk '{print $4 " (" $2 " " $3 ")"}' | grep '^[1-9]' | sort -n |  uniq  | sed -z '$ s/\n$//'
        ;;
    "values gs wfbng bandwidth")
        echo -n -e "20\n40"
        ;;
    "values gs wfbng txpower")
        echo -n -e "1\n100"
        ;;
    "values gs system rx_mode")
        echo -n -e "wfb\napfpv"
        ;;
    "values gs system resolution")
        drm_info -j /dev/dri/card0 2>/dev/null | jq -r '."/dev/dri/card0".connectors[1].modes[] | select(.name | contains("i") | not) | .name + "@" + (.vrefresh|tostring)' | sort | uniq  | sed -z '$ s/\n$//'
        ;;
    "values gs system rec_fps")
        echo -n -e "60\n90\n120"
        ;;

    "get gs system rx_mode")
        systemctl is-enabled --quiet wifibroadcast && echo wfb || echo apfpv
    ;;
    "get gs system gs_rendering")
        [ "$(grep ^render /config/setup.txt | cut -d ' ' -f 3)" = "ground" ] && echo 1 || echo 0
        ;;
    "get gs system resolution")
        drm_info -j /dev/dri/card0 2>/dev/null | jq -r '."/dev/dri/card0".crtcs[0].mode| .name + "@" + (.vrefresh|tostring)'
        ;;
    "get gs system rec_fps")
        grep ^rec_fps /config/setup.txt | cut -d ' ' -f 3 
        ;;
    "set gs system rx_mode"*)
            EXCLUDE_IFACE="wlan0"
            SSID="${6:-OpenIPC}"
            PASSWORD="${7:-12345678}"
            if [ "$5" = "apfpv" ]
            then
                systemctl stop alink_gs.service
                systemctl stop wifibroadcast.service
                systemctl stop wifibroadcast@gs.service
                systemctl disable wifibroadcast.service
                systemctl disable wifibroadcast@gs.service
                systemctl disable alink_gs.service
                rmmod 8812eu
                rmmod 88XXau_wfb
                modprobe 8812eu
                modprobe 88XXau_wfb
                # list every wifi interface wlx or wlan expect wlan0
                WIFI_IFACES=$(ip -o link show | awk -F': ' '{print $2}' | grep '^wlx' | grep -v "^$EXCLUDE_IFACE$")
                INDEX=0
                for IFACE in $WIFI_IFACES; do
                    nmcli device set $IFACE managed yes
                    CONN_NAME="apfpv$INDEX"
                    if nmcli connection show "$CONN_NAME" &>/dev/null; then
                        nmcli connection modify "$CONN_NAME" connection.autoconnect $([ "$INDEX" -eq 0 ] && echo "yes" || echo "no")
                    else
                        nmcli device wifi rescan ifname "$IFACE"
                        sleep 2
                        nmcli connection add type wifi ifname "$IFACE" con-name "$CONN_NAME" ssid "$SSID" \
                            wifi-sec.key-mgmt wpa-psk wifi-sec.psk "$PASSWORD" \
                            ipv4.method auto connection.autoconnect $([ "$INDEX" -eq 0 ] && echo "yes" || echo "no")
                    fi
                    nmcli connection modify "$CONN_NAME" ipv4.route-metric $((100 * (INDEX + 1)))
                    INDEX=$((INDEX + 1))
                done
                ln -s /usr/local/bin/gsmenu.sh /etc/NetworkManager/dispatcher.d/
                nmcli -w 0 connection up apfpv0
        elif [ "$5" = "wfb" ]
        then
            rm /etc/NetworkManager/dispatcher.d/gsmenu.sh
            WIFI_IFACES=$(ip -o link show | awk -F': ' '{print $2}' | grep -E '^wlx' | grep -v "^$EXCLUDE_IFACE$")
            INDEX=0
            for IFACE in $WIFI_IFACES; do
                CONN_NAME="apfpv$INDEX"
                if nmcli connection show "$CONN_NAME" &>/dev/null; then
                    nmcli connection modify "$CONN_NAME" connection.autoconnect no
                    nmcli connection down "$IFACE"
                fi
                INDEX=$((INDEX + 1))
            done
            rmmod 8812eu
            rmmod 88XXau_wfb
            modprobe 8812eu
            modprobe 88XXau_wfb
            systemctl start wifibroadcast.service
            systemctl start wifibroadcast@gs.service
            systemctl start alink_gs.service
            systemctl enable wifibroadcast.service
            systemctl enable wifibroadcast@gs.service
            systemctl enable alink_gs.service
        fi
        ;;
    "set gs system gs_rendering"*)
        if [ "$5" = "off" ]
        then
            sed -i 's/^render =.*/render = air/' /config/setup.txt
            kill -9 $(pidof msposd_rockchip)
        else
            sed -i 's/^render =.*/render = ground/' /config/setup.txt
            msposd_rockchip --osd --ahi 0 --matrix 11 -v -r 5 --master 0.0.0.0:14551 &
        fi
        ;;
    "set gs system resolution"*)
        sed -i "s/^screen_mode =.*/screen_mode = $5/" /config/setup.txt
        ;;
    "set gs system rec_fps"*)
        sed -i "s/^rec_fps =.*/rec_fps = $5/" /config/setup.txt
        ;;
    "set gs system rec_enabled"*)
        if [ "$5" = "off" ]
        then
            : #noop
        else
            : #noop
        fi
        ;;
    "get gs wifi hotspot")
        nmcli connection show --active | grep -q "Hotspot" && echo 1 || echo 0
        ;;
    "get gs wifi wlan")
        connection=$(nmcli -t connection show --active | grep wlan0 | cut -d : -f1)
        [ -z "${connection}" ] && echo 0 || echo 1
        ;;
    "get gs wifi ssid")
        if [ -d /sys/class/net/wlan0 ]; then
            nmcli -t connection show --active | grep wlan0 | cut -d : -f1
        else
            echo -n ""
        fi
        ;;
    "get gs wifi password")
        if [ -d /sys/class/net/wlan0 ]; then
            connection=$(nmcli -t connection show --active | grep wlan0 | cut -d : -f1)
            nmcli -t connection show $connection --show-secrets | grep 802-11-wireless-security.psk: | cut -d : -f2
        else
            echo -n ""
        fi
        ;;
    "get gs wifi IP")
        ip -4 addr show  | grep -oP '(?<=inet\s)\d+(\.\d+){3}'
        ;;
    "set gs wifi wlan"*)
        [ ! -d /sys/class/net/wlan0 ] && exit 0 # we have no wifi
        if [ "$5" = "on" ]
        then
            # Check if connection already exists
            if nmcli connection show | grep -q "$6"; then
                echo "$6 connection exists. Starting it..."
                nmcli con up "$6"
            else
                echo "Creating new "$6" connection..."
                nmcli device wifi connect "$6" password "$7" ifname wlan0
                echo "Starting Wlan..."
                nmcli con up "$6"
            fi
        else
            nmcli con down "$6"
        fi
        ;;
    "set gs wifi hotspot"*)
        [ ! -d /sys/class/net/wlan0 ] && exit 0 # we have no wifi
        if [ "$5" = "on" ]
        then
            # Check if connection already exists
            if nmcli connection show | grep -q "Hotspot"; then
                echo "Hotspot connection exists. Starting it..."
                nmcli con up Hotspot
            else
                echo "Creating new Hotspot connection..."
                nmcli con add type wifi ifname wlan0 con-name Hotspot autoconnect no ssid "OpenIPC GS"
                nmcli con modify Hotspot 802-11-wireless.mode ap 802-11-wireless.band bg ipv4.method shared
                nmcli con modify Hotspot wifi-sec.key-mgmt wpa-psk
                nmcli con modify Hotspot wifi-sec.psk "openipcgs"
                nmcli con modify Hotspot ipv4.addresses 192.168.4.1/24
                echo "Starting Hotspot..."
                nmcli con up Hotspot
            fi
        else
            nmcli con down Hotspot
        fi
        ;;

    "get gs wfbng adaptivelink")
        systemctl is-active --quiet alink_gs.service && echo 1 || echo 0
        ;;
    "get gs wfbng gs_channel")
        channel=$(grep wifi_channel /etc/wifibroadcast.cfg | cut -d ' ' -f 3)
        iw list | grep "\[$channel\]" | tr -d '[]' | awk '{print $4 " (" $2 " " $3 ")"}' | sort -n | uniq
        ;;
    "get gs wfbng bandwidth")
        grep ^bandwidth /etc/wifibroadcast.cfg | cut -d ' ' -f 3
        ;;
    "get gs wfbng txpower")
        wifi_txpower=$(grep ^wifi_txpower /etc/wifibroadcast.cfg)
        [ -z "$wifi_txpower" ] && echo "50" && exit 0
        read first_card first_card_power < <(
            echo "$wifi_txpower" | cut -d = -f 2 | jq -r '"\(to_entries[0].key) \(to_entries[0].value)"'
        )
        first_card_type=$(udevadm info /sys/class/net/${first_card}/ | grep -E 'ID_NET_DRIVER=(rtl88xxau_wfb|rtl88x2eu)'| cut -d = -f2)
        case "$first_card_type" in
        "rtl88xxau_wfb")
            min_phy_txpower=-1000
            max_phy_txpower=-3000
            ;;

        "rtl88x2eu")
            min_phy_txpower=1000
            max_phy_txpower=2900
            ;;
        esac
        range=$((max_phy_txpower - min_phy_txpower))
        position=$((first_card_power - min_phy_txpower))
        percentage=$(( (position * 100) / range ))
        echo $percentage
        ;;

    "set gs wfbng adaptivelink"*)
        if [ "$5" = "on" ]
        then
            systemctl start alink_gs.service
            systemctl enable alink_gs.service
        else
            systemctl stop alink_gs.service
            systemctl disable alink_gs.service
        fi
        ;;
    "set gs wfbng gs_channel"*)
        channel=$(echo $5 | awk '{print $1}')
        if [ "$GSMENU_VTX_DETECTED" -eq "1" ]; then
            $SSH wifibroadcast cli -s .wireless.channel $channel
            $SSH "(wifibroadcast stop ;wifibroadcast stop; sleep 1;  wifibroadcast start) >/dev/null 2>&1 &"
        fi
        sed -i "s/^wifi_channel =.*/wifi_channel = $channel/" /etc/wifibroadcast.cfg
        systemctl restart wifibroadcast.service
        ;;
    "set gs wfbng bandwidth"*)
        sed -i "s/^bandwidth = .*/bandwidth = $5/" /etc/wifibroadcast.cfg
        systemctl restart wifibroadcast.service
        ;;
    "set gs wfbng txpower"*)
        .  /etc/default/wifibroadcast
        wifi_txpower=""
        for nic in $WFB_NICS
        do
            card_type=$(udevadm info /sys/class/net/${nic}/ | grep -E 'ID_NET_DRIVER=(rtl88xxau_wfb|rtl88x2eu)'| cut -d = -f2)
            case "$card_type" in
            "rtl88xxau_wfb")
                min_phy_txpower=-1000
                max_phy_txpower=-3000
                ;;

            "rtl88x2eu")
                min_phy_txpower=1000
                max_phy_txpower=2900
                ;;
            esac
            range=$((max_phy_txpower - min_phy_txpower))
            percentage=$5
            power_value=$(( min_phy_txpower + (percentage * range) / 100 ))
            [ ! -z "$wifi_txpower" ] && wifi_txpower=$wifi_txpower,
            wifi_txpower=$wifi_txpower" \"$nic\": $power_value"
        done
        if ! grep -A 20 "\[common\]" /etc/wifibroadcast.cfg | grep -q "^wifi_txpower = "; then
            sed -i "/^\[common\]/a\wifi_txpower = {$wifi_txpower}" /etc/wifibroadcast.cfg
        else
            sed -i "s/^wifi_txpower = .*/wifi_txpower = {$wifi_txpower}/" /etc/wifibroadcast.cfg
        fi
        systemctl restart wifibroadcast.service
        ;;
    "get gs main Channel")
        gsmenu.sh get gs wfbng gs_channel
        ;;
    "get gs main HDMI-OUT")
        gsmenu.sh get gs system resolution
        ;;
    "get gs main Version")
        cat /config/version.md
        ;;
    "get gs main Disk")
        read -r size avail pcent <<< $(df -h / | awk 'NR==2 {print $2, $4, $5}')
        echo -e "\n   Size: $size\n   Available: $avail\n   Pct: $pcent\c"
        ;;
    "get gs main WFB_NICS")
        grep ^WFB_NICS /etc/default/wifibroadcast | cut -d \" -f 2
        ;;
    "search channel")
        echo "Not implmented"
        echo "Not implmented" >&2
        exit 1
        ;;

    "button air actions Reboot")
        $SSH 'reboot &'
    ;;

    "button gs actions Reboot")
        reboot
    ;;

    "wlx"*"dhcp4-change")
        eval $(udevadm info -x --query=property --path=/sys/class/net/$DEVICE_IFACE)
        case "$ID_NET_DRIVER" in
        "rtl88xxau_wfb")
            iw dev "$DEVICE_IFACE" set txpower fixed -4000
            ;;

        "rtl88x2eu")
            iw dev "$DEVICE_IFACE" set txpower fixed 2500
            ;;
        esac

    ;;
    *)
        echo "Unknown $@"
        exit 1
        ;;
esac

case $? in
    0) ;;
    1) exit 0 ;;
    *) exit $? ;;
esac
